import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
   model: any = {};
  constructor ( private router:Router) {

  }

  ngOnInit() {
  }
   login() {
     if(this.model.username =='customer' && this.model.password =='123456')
     {
       localStorage.setItem('isAuthenticated', 'true');
        this.router.navigate(['/products']);
     }
      else{
        alert('Invalid Username and password.');
      }
   
  }
}

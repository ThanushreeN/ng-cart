import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent }  from './app.component';
import { ProductComponent }  from './components/product/product.component';
import { ProductDetailComponent }  from './components/product-detail/product-detail.component';
import { CartComponent }  from './components/cart/cart.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
   {
    path: '',
    redirectTo:'login',
     pathMatch: 'full'
  },
  {
    path: 'login',
    component:LoginComponent
  },
  {
    path: 'products',
    component: ProductComponent
  },
  {
    path: 'detail/:id',
    component: ProductDetailComponent
  },
  {
    path: 'cart',
    component: CartComponent
  },
  { path: '**', redirectTo: ''}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule { }

# ng2-ShoppingCart
Shopping Cart implementation using angular 2

***Installation***

```
git clone git@github.com:bsubedi26/ng2-ShoppingCart.git
cd ng2-ShoppingCart
npm install
npm install -g angular-cli
No server: ng serve
Server Running: npm run server (change proxy settings in proxy.conf.json file)
```

![Alt text](/screenshots/cart.PNG?raw=true "Cart Page")
![Alt text](/screenshots/details.PNG?raw=true "Product Details Page")
![Alt text](/screenshots/main.PNG?raw=true "Main Product Page")